package com.pkg.compare;
import java.io.File;
import java.io.IOException;


public class Compare {

	public static void main(String[] args) throws IOException, InterruptedException {
		// TODO Auto-generated method stub
		/*File file1 = new File("C:\\Users\\DLT2780\\Documents\\jarPoc1.jar");
		File file2 = new File("C:\\Users\\DLT2780\\Documents\\jarPoc2.jar");
		CompareFile cmpF = new CompareFile();
		// Pass two files to start with, or instruct to prompt
		cmpF.startCompare(file1, file2);*/
		
		String oldjarPath = "C://Users//DLT2780//Documents//jarPoc1.jar";
		String patchJarDiffPath = "C://Users//DLT2780//Documents//jarPoc3.jar";
		//FileOutputStream fos = new FileOutputStream(patchedTrexJarPath.toFile());
		new JarDiffPatcher().applyPatch(null, oldjarPath, patchJarDiffPath);

	}

}

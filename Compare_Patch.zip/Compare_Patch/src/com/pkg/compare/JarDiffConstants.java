package com.pkg.compare;

public interface JarDiffConstants {
	  public static final String VERSION_HEADER = "version 1.0";
	  
	  public static final String INDEX_NAME = "META-INF/INDEX.jd";
	  
	  public static final String REMOVE_COMMAND = "remove";
	  
	  public static final String MOVE_COMMAND = "move";
	}

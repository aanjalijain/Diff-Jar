package com.pkg.compare;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;
import java.util.jar.JarOutputStream;
import java.util.zip.ZipEntry;

public class JarrDiffCompPatch {

	public void applyPatch( Patcher.PatchDelegate delegate, String oldJarPath, String jarDiffPath )
	          throws IOException{
		String jarDiff = jarDiffPath.toString();   // Pass your Jar2 path here which having new changes(Jar2)
		String existingJarName = "C:\\Users\\DLT2780\\Documents\\jarPoc1.jar";   // Pass your New Jar path here which you want to create new(Jar3)
		  List<String> listofDiff= new ArrayList<String>();   // Pass your List here which having changed file names(Complete list off diff)
		  
		  //listFileChanged.add(fileName1);  listFileChanged.add(fileName2); // Remove this line if assigning list directly
		  // Create file descriptors for the jar and a temp jar.
		  File jarFileDiff = new File(jarDiff);
		  File tempJarFile = new File(existingJarName + ".tmp");
		  JarFile jfDiff = new JarFile(jarFileDiff);
		  Enumeration<JarEntry> diffentries = jfDiff.entries();
		    while (diffentries.hasMoreElements()) {
		    	listofDiff.add(( diffentries.nextElement() ).getName());
		    }
		  listofDiff.forEach(print->System.out.println(print));
		  File existJarFile = new File(existingJarName);
		  byte[] buffer = new byte[1024];
		  byte[] buffer1 = new byte[1024];
		  int bytesRead;
		  boolean jarUpdated=false;
		  JarOutputStream tempJar =
			        new JarOutputStream(new FileOutputStream(tempJarFile));
		// Open the jar file.
		  JarFile jarExist;
		  jarExist = new JarFile(existJarFile);
		  try {
              // This will add all changed files to new temp jar with same structure
		        for (Enumeration entries = jarExist.entries(); entries.hasMoreElements(); ) {
		           // Get the next entry.
		           JarEntry entry = (JarEntry) entries.nextElement();
		           // If the entry has not been added already, add it.
		           if(null!=listofDiff){
		        	   if (listofDiff.contains(entry.getName())) {
		 	              // Get an input stream for the entry.
		 	              InputStream entryStream = jfDiff.getInputStream(entry);
		 	              // Read the entry and write it to the temp jar.
		 	              tempJar.putNextEntry(entry);
		 	              while ((bytesRead = entryStream.read(buffer)) != -1) {
		 	                 tempJar.write(buffer, 0, bytesRead);
		 	              }
		 	           }
		        	   else{
		        		   InputStream entryStream1 = jarExist.getInputStream(entry);
			 	              // Read the entry and write it to the temp jar.
		        		   
			 	              tempJar.putNextEntry(entry);
			 	              while ((bytesRead = entryStream1.read(buffer)) != -1) {
			 	                 tempJar.write(buffer1, 0, bytesRead);
			 	              }
			 	            
			 	             
		        	   }
		        	   jarUpdated = true;
		           }
               }
		  }catch(Exception e) {
			  System.out.println(e.getMessage());
			  tempJar.putNextEntry(new JarEntry("stub"));
		  }
		  finally {
		        tempJar.close();
		     }
		  if (jarUpdated) {
			  existJarFile.delete();
			     tempJarFile.renameTo(existJarFile);
			     System.out.println(existJarFile + " updated.");
			  }
		  
	}
}

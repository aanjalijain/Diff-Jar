package com.pkg.compare;



import java.io.IOException;
import java.io.OutputStream;

public interface Patcher {
  void applyPatch(PatchDelegate paramPatchDelegate, String paramString1, String paramString2, OutputStream paramOutputStream) throws IOException;
  
  public static interface PatchDelegate {
    void patching(int param1Int);
  }
}
